// CLASS TOPICS :  Object DATA TYPE

// myValue = {name:"shagun", age:23,email:"info@codesikho.com"}
// console.log(myValue);
// object is written using {} symbol 
// we will write our key:value pair between {} separated by , 
// value maybe a string , array or a object or maybe a number


// HOW TO ACCESS VALUES?
// myValue = {name:"shagun", age:23,email:"info@codesikho.com"}
// myKeyVal= myValue["email"]
// myKeyVal = myValue.age
// console.log(myKeyVal);
// so we can access either entering key name between [] in a string format
// or we can access using . and then key name


// we cannot write value with same key otherwise it will get override
// myValue = {name:"shagun",name:"abc"}
// console.log(myValue.name);
